#include <cstdio>
#include <iostream>
#include <Eigen/Eigen>
#include <limits>
#include <hdrloader.h>

#define TINYOBJLOADER_IMPLEMENTATION
#include <tiny_obj_loader.h>

#define STB_IMAGE_WRITE_IMPLEMENTATION


#include <stb_image_write.h>

#include <vector>
#include <cmath>

using namespace Eigen;
using namespace std;

const float PI = 3.141592;
const int MAX_TRIANGLE_NUM_IN_BOX = 8;
int maxHeight = 0;
int countLeafNode = 0;
int countFaceNum = 0;
bool needTest = false;
bool hasEnvironment = false;
HDRLoaderResult loaderResult;

class Triangle {
public:
	vector<Vector3f> points;
	Vector3f Kd, Ke, Ns;
};

class TreeNode {
public:
	Vector3f minBoxPoint, maxBoxPoint;
	vector<Triangle> ownedTriangls;
	
	TreeNode *children = NULL;
};

class Ray {
public:
	Vector3f startPoint;
	Vector3f direction;
	Ray(Vector3f startPoint, Vector3f direction) : startPoint( startPoint ), direction( direction ) {
		
	}
};


void printVector(Vector3f vector) {
	cout << vector[0] << "  " << vector[1] << "  " << vector[2] << endl;
}

Vector3f getEnvironmentColor(Vector3f d) {

	// �Է���һ,normalizeһ��
	d = d.normalized();
	float phi = acos(d[1]);
	float theta = acos(d[0] / sin(phi)) + PI - PI*2/3;
	if (theta > 2 * PI)
		theta -= 2 * PI;

	int w = theta / 2 / PI * loaderResult.width;
	int h = phi / PI * loaderResult.height;
	if (w >= loaderResult.width)
		w = loaderResult.width - 1;
	if (h >= loaderResult.height)
		h = loaderResult.height - 1;
	if (w < 0)
		w = 0;
	if (h < 0)
		h = 0;
	Vector3f color;
	for (int i = 0; i < 3; i++) {
		float enviLight = loaderResult.cols[(h * loaderResult.width + w) * 3 + i];
		if (enviLight > 1.f)
			enviLight = 1.f;
		color[i] = enviLight;
	}

	color = color * 15;
	//for (int i = 0; i < 3; i++) {
	//	if (color[i] > 1.f)
	//		color[i] = 1;
	//}

	return color;
}

bool isInBox(TreeNode &node, Triangle &face) {

	for (int i = 0; i < 3; i++) {
		Vector3f point = face.points[i];
		for (int j = 0; j < 3; j++) {
			if (!(point[j] > node.minBoxPoint[j] && point[j] < node.maxBoxPoint[j]))
				return false;
		}
	}
	return true;
}

bool isRayPassBox(Ray& ray, TreeNode& node) {

	Vector3f t0 = (node.minBoxPoint - ray.startPoint).cwiseQuotient(ray.direction);
	Vector3f t1 = (node.maxBoxPoint - ray.startPoint).cwiseQuotient(ray.direction);

	// ��֤t0��ֵ�Ƚ�С
	for (int i = 0; i < 3; i++) {
		if (t0[i] > t1[i]) {
			float tmp = t0[i];
			t0[i] = t1[i];
			t1[i] = tmp;
		}
	}


	float minTime = max(max(t0[0], t0[1]), t0[2]);
	float maxTime = min(min(t1[0], t1[1]), t1[2]);

	if (minTime < maxTime)
		return true;
	return false;
}

vector<Triangle> buildOctTree(TreeNode& root, vector<Triangle>& faces, Vector3f &minPoint, Vector3f &maxPoint) {

	root.minBoxPoint = minPoint;
	root.maxBoxPoint = maxPoint;

	int n = faces.size();
	vector<Triangle> remainFaces;
	for (int i = n-1; i >= 0 ; i-- ) {
		if (isInBox(root, faces[i])) {
			root.ownedTriangls.push_back(faces[i]);
		}
		else {
			remainFaces.push_back(faces[i]);
		}
	}

	//cout << "build a node : face num = " << root.ownedTriangls.size() << endl;

	if (root.ownedTriangls.size() > MAX_TRIANGLE_NUM_IN_BOX) {

		root.children = new TreeNode[8];

		float dx = (maxPoint[0] - minPoint[0]) / 2;
		float dy = (maxPoint[1] - minPoint[1]) / 2;
		float dz = (maxPoint[2] - minPoint[2]) / 2;
		Vector3f shift(dx, dy, dz);

		Vector3f minPoints[8];
		minPoints[0] = minPoint + Vector3f(0, 0, 0);
		minPoints[1] = minPoint + Vector3f(dx, 0, 0);
		minPoints[2] = minPoint + Vector3f(0, dy, 0);
		minPoints[3] = minPoint + Vector3f(dx, dy, 0);
		minPoints[4] = minPoint + Vector3f(0, 0, dz);
		minPoints[5] = minPoint + Vector3f(dx, 0, dz);
		minPoints[6] = minPoint + Vector3f(0, dy, dz);
		minPoints[7] = minPoint + Vector3f(dx, dy, dz);

		for (int i = 0; i < 8; i++) {
			Vector3f maxPointForChid = minPoints[i] + shift;
			root.ownedTriangls =  buildOctTree(root.children[i], root.ownedTriangls, minPoints[i], maxPointForChid);
		}


	}
		
	return remainFaces;
	

}



Vector3f brdf(Vector3f normal, Vector3f win, Vector3f wout, Triangle triangle) {
	// ����ʹ����򵥵�brdf
	return triangle.Kd / PI;
}

inline float mixProduct(Vector3f a, Vector3f b, Vector3f c) {
	return a.cross(b).dot(c);
}

Vector3f findIntersectionPoint(Ray ray, vector<Triangle> &faces, Vector3f &intersectionPoint, Triangle &intersectionTriangle, bool &hasIntersection, float &closestN, bool &first) {

	// t��ʾ���ߵķ�������
	Vector3f t = ray.direction.normalized();
	Vector3f color(0, 0, 0);

	for (int i = 0; i < faces.size(); i++) {
		Triangle face = faces[i];
		// ����������ΪA,B,C
		Vector3f A = face.points[0];
		Vector3f B = face.points[1];
		Vector3f C = face.points[2];

		Matrix3f matrix, inverseMatrix;
		Vector3f X1 = B - A, X2 = C - A, X3 = -t, Y = ray.startPoint - A;
		/*matrix << X1[0], X2[0], X3[0],
			X1[1], X2[1], X3[1],
			X1[2], X2[2], X3[2];*/

		/*inverseMatrix = matrix.inverse();
		if ( isnan( inverseMatrix(0, 0) ) )
			continue;

		Vector3f ans = inverseMatrix * Y;*/

		float X = mixProduct(X1, X2, X3);
		if (X == 0.f)
			continue;
		Vector3f ans(mixProduct(Y, X2, X3), mixProduct(X1, Y, X3), mixProduct(X1, X2,Y) );
		ans /= X;

		float b = ans[0], c = ans[1], n = ans[2];
		Vector3f position = (1 - b - c) * A + b * B + c * C;

		if (b >= 0 && b <= 1 && c >= 0 && c <= 1 && (1-b-c) >= 0 && (1-b-c) <= 1 && n > 0 ) {
			if (first || n < closestN ){
				first = false;
				closestN = n;
				color = (B - A).cross(C - A).normalized();
				//color = Vector3f(1 - b - c, b, c);
				intersectionPoint = position;
				intersectionTriangle = face;
				hasIntersection = true;
			}
		}

	}

	return color;
}

float getRandom() {
	// ����0-1֮��������
	return rand() % 1000 / 1000.f;
}

void findIntersectionPointByTree(Ray ray, TreeNode root, Vector3f& intersectionPoint, Triangle& intersectionTriangle, bool& hasIntersection, float& closestN, bool& first) {

	findIntersectionPoint(ray, root.ownedTriangls, intersectionPoint, intersectionTriangle, hasIntersection, closestN, first);

	if (root.children == NULL)
		return;

	for (int i = 0; i < 8; i++) {
		if (isRayPassBox(ray, root.children[i]))
			findIntersectionPointByTree(ray, root.children[i], intersectionPoint, intersectionTriangle, hasIntersection, closestN, first);
	}


}


Vector3f pathTrace(Ray ray, int time, Vector3f weight, TreeNode root ) {

	if (time >= 10)
		return Vector3f(0, 0, 0);

	Vector3f p;
	Triangle face;
	bool hasIntersection = false, first = true;
	float closestN = 0.f;
	findIntersectionPointByTree( ray, root, p, face, hasIntersection, closestN, first);
	
	if (!hasIntersection) {
		if (!hasEnvironment)
			return Vector3f(0.f, 0.f, 0.f);
		else {
			Vector3f enviColor = getEnvironmentColor(ray.direction);
			// ����һ�»�ɫ
			/*if (weight[0] == weight[1] && weight[0] == weight[2] && weight[0] < 1) {
				for (int i = 0; i < 3; i++) {
					if (enviColor[i] > 1.f)
						enviColor[i] = 1.f;
				}
			}*/
			return weight.cwiseProduct( enviColor );

		}
	}
		
	if (face.Ke != Vector3f(0.f, 0.f, 0.f))
		return weight.cwiseProduct( face.Ke/2 );

	//weight = weight.cwiseProduct(face.Kd);
	for (int i = 0; i < 3; i++) {
		float color = face.Kd[i];
		if (color > 1)
			color = 1;
		weight[i] = weight[i] * (1 + cos(asin(color)) * 0) * color;
	}


	// ��������Ҫ������
	Vector3f wout = (-ray.direction).normalized();
	float phi = getRandom() * 2 * PI;
	float theta = acosf(getRandom());
	Vector3f win = Vector3f(sinf(theta) * cosf(phi), sinf(theta) * sinf(phi), cosf(theta)).normalized();
	// �������ε���������Ϊ A.B,C ��ʱ�뷽��
	Vector3f A = face.points[0], B = face.points[1], C = face.points[2];
	Vector3f normal = (B - A).cross(C - A).normalized();
	
	// ��normalƫ��ʱ���ٵ���win��ֵ
	if ( normal[0] != 0.f || normal[1] != 0.f) {
		Vector3f XForNormal = Vector3f(-normal[1],normal[0] , 0).normalized();
		Vector3f YForNormal = normal.cross(XForNormal).normalized();
		win = win[0] * XForNormal + win[1] * YForNormal + win[2] * normal;
	}

	Vector3f BRDF = brdf(normal, win, wout, face);
	Vector3f Lin = pathTrace(Ray(p, win), time + 1, weight, root);
	
	if (needTest) {
		cout << "time = " << time << endl;
		cout << "weight = ";
		printVector(weight);
		cout << "normal = ";
		printVector(normal);
		cout << "Lin = ";
		printVector(Lin);
		cout << "face.kd";
		printVector(face.Kd);
		cout << endl;

	}

	return Lin;
		
	return face.Ke + normal.dot(win) * Vector3f( BRDF[0] * Lin[0], BRDF[1] * Lin[1], BRDF[2] * Lin[2]);

}


void getFaces(string inputfile, vector<Triangle>& faces) {

	tinyobj::ObjReaderConfig reader_config;
	reader_config.mtl_search_path = "./";

	tinyobj::ObjReader reader;
	
	if (!reader.ParseFromFile(inputfile, reader_config)) {
		if (!reader.Error().empty()) {
			std::cerr << "TinyObjReader: " << reader.Error();
		}
		exit(1);
	}

	if (!reader.Warning().empty()) {
		std::cout << "TinyObjReader: " << reader.Warning();
	}

	auto& attrib = reader.GetAttrib();
	auto& shapes = reader.GetShapes();
	auto& materials = reader.GetMaterials();

	cout << "shapes.size() = " << shapes.size() << endl;
	


	for (size_t s = 0; s < shapes.size(); s++) {
		// Loop over faces(polygon)
		size_t index_offset = 0;
		cout << "s = " << s << " faceNum = " << shapes[s].mesh.num_face_vertices.size() << endl;
		for (size_t f = 0; f < shapes[s].mesh.num_face_vertices.size(); f++) {
			size_t fv = size_t(shapes[s].mesh.num_face_vertices[f]);

			Triangle face;

			// Loop over vertices in the face.
			for (size_t v = 0; v < fv; v++) {
				// access to vertex
				tinyobj::index_t idx = shapes[s].mesh.indices[index_offset + v];
				tinyobj::real_t vx = attrib.vertices[3 * size_t(idx.vertex_index) + 0];
				tinyobj::real_t vy = attrib.vertices[3 * size_t(idx.vertex_index) + 1];
				tinyobj::real_t vz = attrib.vertices[3 * size_t(idx.vertex_index) + 2];

				face.points.push_back (Vector3f(vx, vy, vz));

				// Check if `normal_index` is zero or positive. negative = no normal data
				//if (idx.normal_index >= 0) {
				//	tinyobj::real_t nx = attrib.normals[3 * size_t(idx.normal_index) + 0];
				//	tinyobj::real_t ny = attrib.normals[3 * size_t(idx.normal_index) + 1];
				//	tinyobj::real_t nz = attrib.normals[3 * size_t(idx.normal_index) + 2];
				//}

				// Check if `texcoord_index` is zero or positive. negative = no texcoord data
				//if (idx.texcoord_index >= 0) {
				//	tinyobj::real_t tx = attrib.texcoords[2 * size_t(idx.texcoord_index) + 0];
				//	tinyobj::real_t ty = attrib.texcoords[2 * size_t(idx.texcoord_index) + 1];
				//}
				

				// Optional: vertex colors
				// tinyobj::real_t red   = attrib.colors[3*size_t(idx.vertex_index)+0];
				// tinyobj::real_t green = attrib.colors[3*size_t(idx.vertex_index)+1];
				// tinyobj::real_t blue  = attrib.colors[3*size_t(idx.vertex_index)+2];
			}
			index_offset += fv;

			// per-face material
			int materialId = shapes[s].mesh.material_ids[f];
			if (materialId >= 0) {
				face.Kd = Vector3f(materials[materialId].diffuse[0], materials[materialId].diffuse[1], materials[materialId].diffuse[2]);
				face.Ke = Vector3f(materials[materialId].emission[0], materials[materialId].emission[1], materials[materialId].emission[2]);

			}
			
			//face.Ns = Vector3f(materials[materialId].shininess[0], materials[materialId].shininess[1], materials[materialId].shininess[2]);
			faces.push_back(face);
		}
	}


}

void traversalOctTree( TreeNode root, int height ) {

	if (height > maxHeight)
		maxHeight = height;
	
	countFaceNum += root.ownedTriangls.size();

	if (root.children != NULL) {
		for (int i = 0; i < 8; i++) {
			traversalOctTree(root.children[i], height + 1);
		}
	}
	else {
		countLeafNode++;
	}

}


int main() {

	// Configs
	Vector3f position(0.f, 12.72, 31.85);
	Vector3f lookAt(0.f, 12.546, 30.865);
	Vector3f up(0.f, 0.985, -0.174);
	float fov = PI / 4;

	vector<Vector3f> output;
	Vector3f eye = position;
	Vector3f screen = lookAt;

	// m,n��ʾͼƬ���ص�����������
	const int width = 800, height = 400;
	float heightSize = (position - lookAt).norm() * tan( fov/2 ) * 2;
	float widthSize = heightSize / height * width;
	Vector3f Z = (position - lookAt).normalized();
	Vector3f Y = up.normalized();
	Vector3f X = Y.cross(Z).normalized();


	//faces.push_back(Triangle{ {
	//	Vector3f(-1,-1,1),
	//	Vector3f(1,-1,1),
	//	Vector3f(0,1,1)
	//} });
	
	// ����faces���������˲���
	vector<Triangle> faces;
	string inputfile = "diningroom.obj";
	getFaces(inputfile, faces);
	cout << faces.size() << endl;

	// ��ȡ����
	string environmentFile = "environment.hdr";
	if (!HDRLoader::load( environmentFile.c_str(), loaderResult ))
		cout << "load error";
	hasEnvironment = true;
	
	cout << loaderResult.height << "  " << loaderResult.width << endl;
	int n = loaderResult.height * loaderResult.width * 3;
	vector<unsigned char> enviData;
	for (int i = 0; i < n; i++) {
		enviData.push_back(( (loaderResult.cols[i])  > 1.f ? 1.f : (loaderResult.cols[i]) )*255.9);
	}
	stbi_write_bmp("diningroom_envi.bmp",loaderResult.width , loaderResult.height, 3, enviData.data());

	vector<unsigned char> testEnviData;
	float phi = 0.f, theta = 0.f;
	float dphi = PI / loaderResult.height, dtheta = 2 * PI / loaderResult.width;
	for (int i = 0; i < loaderResult.height; i++) {
		for (int j = 0; j < loaderResult.width; j++) {
			phi = i * dphi;
			theta = j * dtheta + PI ;
			if (theta > 2 * PI)
				theta -= 2 * PI;
			int w = theta / 2 / PI * loaderResult.width;
			int h = phi / PI * loaderResult.height;
			testEnviData.push_back(enviData[(h * loaderResult.width + w) * 3]);
			testEnviData.push_back(enviData[(h * loaderResult.width + w) * 3+1]);
			testEnviData.push_back(enviData[(h * loaderResult.width + w) * 3+2]);

		}
	}
	stbi_write_bmp("diningroom_envi_test.bmp", loaderResult.width, loaderResult.height, 3, testEnviData.data());

	//return 0;

	TreeNode root;
	float minX = numeric_limits<float>::max(), minY = numeric_limits<float>::max(), minZ = numeric_limits<float>::max();
	float maxX = numeric_limits<float>::min(), maxY = numeric_limits<float>::min(), maxZ = numeric_limits<float>::min();
	for (int i = 0; i < faces.size(); i++) {
		Triangle face = faces[i];
		for (int i = 0; i < 3; i++) {
			Vector3f point = face.points[i];
			minX = min(minX, point[0]);
			minY = min(minY, point[1]);
			minZ = min(minZ, point[2]);
			maxX = max(maxX, point[0]);
			maxY = max(maxY, point[1]);
			maxZ = max(maxZ, point[2]);
		}
	}
	Vector3f minPoint(minX -0.001, minY - 0.001 , minZ - 0.001 );
	Vector3f maxPoint(maxX + 0.001 , maxY + 0.001 , maxZ + 0.001 );

	//Vector3f minPoint(minX, minY, minZ);
	//Vector3f maxPoint(maxX, maxY, maxZ);

	cout << "minpoint: \n" <<   minPoint << "\n   maxpoint: \n" << maxPoint << endl;
	cout << "start build tree......" << endl;
	buildOctTree(root, faces, minPoint, maxPoint);
	cout << "end build tree ....." << endl;
	traversalOctTree(root, 0);
	printf("countLeaf = %d, height = %d, faceNum = %d\n", countLeafNode, maxHeight, countFaceNum);

	cout << root.ownedTriangls.size() << endl;
	/*for (int i = 0; i < root.ownedTriangls.size(); i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				cout << root.ownedTriangls[i].points[j][k] << "/";
			}
			cout << "      ";
		}
		cout << endl;
	}
	cout << endl; 
	cout << endl;
	cout << faces.size() << endl;
	for (int i = 0; i < faces.size(); i++) {
		for (int j = 0; j < 3; j++) {
			for (int k = 0; k < 3; k++) {
				cout << faces[i].points[j][k] << "/";
			}
			cout << "      ";
		}
		cout << endl;
	}*/
	//Triangle testTriangle;
	//testTriangle.points.push_back(Vector3f(-1.f, -1.f, 1.f));
	//testTriangle.points.push_back(Vector3f(1.f, -1.f, 1.f));
	//testTriangle.points.push_back(Vector3f(1.f, -1.f, -1.f));
	//cout << "is in root :" << isInBox(root, testTriangle) << endl;
	//for (int i = 0; i < 8; i++) {
	//	cout << "child " << i << ": " << isInBox(root.children[i], testTriangle) << endl;
	//}




	//return 0;
	
	
	// ������ֻ�ü򵥵Ĺ���׷��
	//for (int i = 0; i < height; i++) {
	//	for (int j = 0; j < width; j++) {
	//		//Vector3f color = Vector3f(0, 0, 0);
	//		//Vector3f color = i < m / 2 ? Vector3f(1, 0, 0) : Vector3f(0, 1, 0);
	//		Vector3f point;
	//		Triangle triangle;
	//		bool flag = false;
	//		float closesetN = 0.f;
	//		bool first = true;
	//		output.push_back(findIntersectionPoint( Ray( eye, startPoint + Vector3f(dw*j, -dh*i, 0) - eye ), root.ownedTriangls, point, triangle, flag, closesetN, first ));
	//		cout << i << " " << j << endl;
	//		//output.push_back(color);
	//	}
	//}


	// startPoint����Ļ�����Ͻ�
	Vector3f startPoint = screen + heightSize / 2 * Y - widthSize / 2 * X;
	float dw = widthSize / width, dh = heightSize / height;
	
	int N = 10;
	unsigned char data[width * height * 3];

	for (int i = 0; i < height; i++) {
		cout << i << endl;
#pragma omp parallel for
		for (int j = 0; j < width; j++) {
			Vector3f sum(0.f, 0.f, 0.f);
			//if (i == 30 && j == 7)
			//	needTest = true;
			for (int k = 0; k < N; k++) {
				float randomWidth = dw * getRandom();
				float randomHeight = dh * getRandom();
				Ray ray(eye, ( startPoint + (dw * j + randomWidth) * X - (dh * i + randomHeight) * Y - eye ).normalized() );
				//cout << isRayPassBox(ray, root) << endl;
				if (isRayPassBox(ray, root)) {
					Vector3f point = pathTrace(ray, 0, Vector3f(1, 1, 1), root);
					sum += point;
				}
				else if ( hasEnvironment ){
					sum += getEnvironmentColor(ray.direction);
				}
					
			}
			/*if (i == 82 && j == 25)
				sum = N * Vector3f(0, 0, 1);*/
			if (needTest)
				cout << " color = " << sum[0]/N << " " << sum[1]/N << " " << sum[2]/N << endl;
			Vector3f color = sum / N;
			// ��ֹ���
			for (int k = 0; k < 3; k++) {
				if (color[k] > 1.f) {
					color[k] = 1.f;
				}
			}
			/*output.push_back(color);*/
			
			data[ (i * width + j) * 3 ] = color[0] * 255.9;
			data[(i * width + j) * 3 + 1] = color[1] * 255.9;
			data[(i * width + j) * 3 + 2] = color[2] * 255.9;
			
			//cout << i << " " << j << endl;

			//if (needTest)
			//	return 0;
		}

	}


	
	stbi_write_bmp("dining_room.bmp",width , height , 3, data);
	

	return 0;
}




